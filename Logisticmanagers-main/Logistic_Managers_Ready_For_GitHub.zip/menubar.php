    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
      <a class="navbar-brand" href="#"><img src="https://res.cloudinary.com/dqbueilyh/image/upload/v1698060611/WhatsApp_Image_2023-10-23_at_10.41.28_h8fzat.jpg" class="logo_img"/></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="About Us.php">About Us</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="Registration Form.php">Registration Form</a>
          </li>
          <li class="nav-item active">
              <a class="nav-link" href="Services.php">Services</a>
          </li>
          <li class="nav-item active">
              <a class="nav-link" href="Contact us.php">Contact Us</a>
          </li>
        </ul>
      </div>
    </nav>
